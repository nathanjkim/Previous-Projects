import java.awt.Color;

public class AngryEyebrows
{
   public static void main(String[] args)
   {       	
      String fName = "angrybirdwithouteyebrow.jpg";
      Picture picture = new Picture(fName);
      picture.show();
   	
      picture.getPixel(338,273).setColor(Color.black);
      picture.getPixel(339,273).setColor(Color.black);
      picture.getPixel(340,273).setColor(Color.black);
      picture.getPixel(341,273).setColor(Color.black);
      picture.getPixel(342,273).setColor(Color.black);
      picture.getPixel(343,273).setColor(Color.black);
      picture.getPixel(344,273).setColor(Color.black);
      picture.getPixel(345,273).setColor(Color.black);
      picture.getPixel(346,273).setColor(Color.black);
      picture.getPixel(347,273).setColor(Color.black);
      
      picture.explore();         //allows to search color by pixel
   
   }
}